.. _introduction:

Introduction
============

Neper's developer documentation gathers information on methods and algorithms that are used in Neper but that may not be described in other resources, such as reference articles or the user documentation.  It is not an exhaustive document and may also serve as a cheatsheet.
