.. _fdl_link:

******************************
GNU Free Documentation License
******************************

.. literalinclude:: _static/fdl.txt
