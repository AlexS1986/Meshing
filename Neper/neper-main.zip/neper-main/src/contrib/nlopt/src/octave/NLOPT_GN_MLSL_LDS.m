% NLOPT_GN_MLSL_LDS: Multi-level single-linkage (MLSL), quasi-random (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_MLSL_LDS
  val = 22;
