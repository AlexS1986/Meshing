---
# NLopt R Reference
---

An NLopt interface for [GNU R](https://en.wikipedia.org/wiki/GNU_R) was developed by [Jelmer Ypma](http://www.ucl.ac.uk/~uctpjyy) at [University College London](https://en.wikipedia.org/wiki/University_College_London) (UCL), and is currently available as a separate download (with documentation) from:

-   [<http://www.ucl.ac.uk/~uctpjyy/nloptr.html>](http://www.ucl.ac.uk/~uctpjyy/nloptr.html)
