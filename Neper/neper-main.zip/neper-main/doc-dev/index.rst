.. _neper_link:

Neper's Developer Documentation
+++++++++++++++++++++++++++++++

.. toctree::
   :maxdepth: 2

   copying.rst
   introduction.rst
   regularization.rst
   1dmeshing.rst
   smoothing.rst
   1dlaguerre.rst
   ellipse.rst
   gpl.rst
   fdl.rst

* :ref:`genindex`
